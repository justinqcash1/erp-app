"use client";

import React from 'react';
import { useRouter } from 'next/navigation';
import { useSession } from 'next-auth/react';
import { TruckingTicketForm } from '@/components/trucking-ticket-form';
import { toast } from '@/components/ui/toast';

export default function CreateTruckingTicketPage() {
  const router = useRouter();
  const { data: session, status } = useSession();
  const [projects, setProjects] = React.useState([]);
  const [contractors, setContractors] = React.useState([]);
  const [materials, setMaterials] = React.useState([]);
  const [loading, setLoading] = React.useState(true);

  // Fetch projects, contractors, and materials on component mount
  React.useEffect(() => {
    const fetchData = async () => {
      try {
        // Fetch projects
        const projectsResponse = await fetch('/api/projects');
        const projectsData = await projectsResponse.json();
        
        // Fetch contractors
        const contractorsResponse = await fetch('/api/trucking-contractors');
        const contractorsData = await contractorsResponse.json();
        
        // Fetch materials
        const materialsResponse = await fetch('/api/materials');
        const materialsData = await materialsResponse.json();
        
        setProjects(projectsData);
        setContractors(contractorsData);
        setMaterials(materialsData);
      } catch (error) {
        console.error('Error fetching data:', error);
        toast({
          title: 'Error',
          description: 'Failed to load required data',
          variant: 'destructive',
        });
      } finally {
        setLoading(false);
      }
    };
    
    if (status === 'authenticated') {
      fetchData();
    }
  }, [status]);

  // Handle form submission
  const handleSubmit = async (data) => {
    try {
      const response = await fetch('/api/trucking-tickets', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to create trucking ticket');
      }
      
      const ticket = await response.json();
      
      toast({
        title: 'Success',
        description: 'Trucking ticket created successfully',
        variant: 'success',
      });
      
      // Redirect to the ticket list page
      router.push('/trucking-tickets');
    } catch (error) {
      console.error('Error creating trucking ticket:', error);
      toast({
        title: 'Error',
        description: error.message || 'Failed to create trucking ticket',
        variant: 'destructive',
      });
    }
  };

  // Show loading state
  if (status === 'loading' || loading) {
    return <div>Loading...</div>;
  }

  // Redirect if not authenticated
  if (status === 'unauthenticated') {
    router.push('/auth/signin');
    return null;
  }

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-2xl font-bold mb-6">Create Trucking Ticket</h1>
      
      <TruckingTicketForm
        projects={projects}
        contractors={contractors}
        materials={materials}
        onSubmit={handleSubmit}
      />
    </div>
  );
}
