"use client";

import React from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { useSession } from 'next-auth/react';
import { TruckingTicketList } from '@/components/trucking-ticket-list';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/toast';

export default function TruckingTicketsPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { data: session, status } = useSession();
  const [tickets, setTickets] = React.useState([]);
  const [projects, setProjects] = React.useState([]);
  const [loading, setLoading] = React.useState(true);
  const [filters, setFilters] = React.useState({
    projectId: searchParams.get('projectId') || '',
    status: searchParams.get('status') || '',
    ticketType: searchParams.get('ticketType') || '',
    search: searchParams.get('search') || '',
  });

  // Fetch tickets and projects on component mount and when filters change
  React.useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        
        // Build query string from filters
        const queryParams = new URLSearchParams();
        if (filters.projectId) queryParams.append('projectId', filters.projectId);
        if (filters.status) queryParams.append('status', filters.status);
        if (filters.ticketType) queryParams.append('ticketType', filters.ticketType);
        if (filters.search) queryParams.append('search', filters.search);
        
        // Fetch tickets
        const ticketsResponse = await fetch(`/api/trucking-tickets?${queryParams.toString()}`);
        const ticketsData = await ticketsResponse.json();
        
        // Fetch projects for filter dropdown
        const projectsResponse = await fetch('/api/projects');
        const projectsData = await projectsResponse.json();
        
        setTickets(ticketsData);
        setProjects(projectsData);
      } catch (error) {
        console.error('Error fetching data:', error);
        toast({
          title: 'Error',
          description: 'Failed to load trucking tickets',
          variant: 'destructive',
        });
      } finally {
        setLoading(false);
      }
    };
    
    if (status === 'authenticated') {
      fetchData();
    }
  }, [status, filters]);

  // Handle filter changes
  const handleFilterChange = (newFilters) => {
    setFilters((prev) => ({ ...prev, ...newFilters }));
    
    // Update URL with filters
    const queryParams = new URLSearchParams();
    if (newFilters.projectId) queryParams.append('projectId', newFilters.projectId);
    if (newFilters.status) queryParams.append('status', newFilters.status);
    if (newFilters.ticketType) queryParams.append('ticketType', newFilters.ticketType);
    if (newFilters.search) queryParams.append('search', newFilters.search);
    
    router.push(`/trucking-tickets?${queryParams.toString()}`);
  };

  // Handle ticket selection for viewing details
  const handleTicketSelect = (ticket) => {
    router.push(`/trucking-tickets/${ticket.id}`);
  };

  // Show loading state
  if (status === 'loading' || loading) {
    return <div>Loading...</div>;
  }

  // Redirect if not authenticated
  if (status === 'unauthenticated') {
    router.push('/auth/signin');
    return null;
  }

  return (
    <div className="container mx-auto py-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Trucking Tickets</h1>
        <Button onClick={() => router.push('/trucking-tickets/create')}>
          Create New Ticket
        </Button>
      </div>
      
      <TruckingTicketList
        tickets={tickets}
        projects={projects}
        onFilterChange={handleFilterChange}
        onTicketSelect={handleTicketSelect}
      />
      
      <div className="mt-8">
        <h2 className="text-xl font-semibold mb-4">Monthly Statistics</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white p-4 rounded shadow">
            <h3 className="font-medium">Total Tickets This Month</h3>
            <p className="text-2xl">{tickets.length}</p>
          </div>
          <div className="bg-white p-4 rounded shadow">
            <h3 className="font-medium">Uninvoiced Tickets</h3>
            <p className="text-2xl">{tickets.filter(t => t.status === 'LOGGED').length}</p>
          </div>
          <div className="bg-white p-4 rounded shadow">
            <h3 className="font-medium">Total Amount</h3>
            <p className="text-2xl">
              ${tickets.reduce((sum, ticket) => sum + ticket.totalAmount, 0).toFixed(2)}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
