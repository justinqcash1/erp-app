"use client";

import React from 'react';
import { useParams, useRouter } from 'next/navigation';
import { useSession } from 'next-auth/react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { toast } from '@/components/ui/toast';

export default function TruckingTicketDetailPage() {
  const params = useParams();
  const router = useRouter();
  const { data: session, status } = useSession();
  const [ticket, setTicket] = React.useState(null);
  const [loading, setLoading] = React.useState(true);
  const ticketId = params.id;

  // Fetch ticket details on component mount
  React.useEffect(() => {
    const fetchTicket = async () => {
      try {
        setLoading(true);
        
        const response = await fetch(`/api/trucking-tickets/${ticketId}`);
        
        if (!response.ok) {
          throw new Error('Failed to fetch ticket details');
        }
        
        const data = await response.json();
        setTicket(data);
      } catch (error) {
        console.error('Error fetching ticket details:', error);
        toast({
          title: 'Error',
          description: error.message || 'Failed to load ticket details',
          variant: 'destructive',
        });
      } finally {
        setLoading(false);
      }
    };
    
    if (status === 'authenticated' && ticketId) {
      fetchTicket();
    }
  }, [status, ticketId]);

  // Handle ticket status update
  const handleStatusUpdate = async (newStatus) => {
    try {
      const response = await fetch(`/api/trucking-tickets/${ticketId}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ status: newStatus }),
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to update ticket status');
      }
      
      const updatedTicket = await response.json();
      setTicket(updatedTicket);
      
      toast({
        title: 'Success',
        description: 'Ticket status updated successfully',
        variant: 'success',
      });
    } catch (error) {
      console.error('Error updating ticket status:', error);
      toast({
        title: 'Error',
        description: error.message || 'Failed to update ticket status',
        variant: 'destructive',
      });
    }
  };

  // Format date for display
  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString();
  };

  // Get status badge color
  const getStatusBadge = (status) => {
    switch (status) {
      case 'LOGGED':
        return <Badge variant="outline">Logged</Badge>;
      case 'INVOICED':
        return <Badge variant="success">Invoiced</Badge>;
      case 'DISPUTED':
        return <Badge variant="destructive">Disputed</Badge>;
      case 'VOID':
        return <Badge variant="secondary">Void</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  // Show loading state
  if (status === 'loading' || loading) {
    return <div>Loading...</div>;
  }

  // Redirect if not authenticated
  if (status === 'unauthenticated') {
    router.push('/auth/signin');
    return null;
  }

  // Show error if ticket not found
  if (!ticket) {
    return (
      <div className="container mx-auto py-8">
        <h1 className="text-2xl font-bold mb-6">Ticket Not Found</h1>
        <p>The requested trucking ticket could not be found.</p>
        <Button className="mt-4" onClick={() => router.push('/trucking-tickets')}>
          Back to Tickets
        </Button>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Trucking Ticket Details</h1>
        <Button onClick={() => router.push('/trucking-tickets')}>
          Back to Tickets
        </Button>
      </div>
      
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle>Ticket #{ticket.ticketNumber}</CardTitle>
            {getStatusBadge(ticket.status)}
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="font-semibold mb-4">Ticket Information</h3>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-500">Ticket Date:</span>
                  <span>{formatDate(ticket.ticketDate)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Ticket Type:</span>
                  <span>{ticket.ticketType === 'MATERIAL' ? 'Material' : 'Hourly'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Rate:</span>
                  <span>${ticket.rate.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Total Amount:</span>
                  <span>${ticket.totalAmount.toFixed(2)}</span>
                </div>
                {ticket.ticketType === 'MATERIAL' && (
                  <div className="flex justify-between">
                    <span className="text-gray-500">Quantity:</span>
                    <span>{ticket.quantity} {ticket.material?.unitOfMeasure || ''}</span>
                  </div>
                )}
                {ticket.ticketType === 'HOURLY' && (
                  <div className="flex justify-between">
                    <span className="text-gray-500">Hours:</span>
                    <span>{ticket.hours}</span>
                  </div>
                )}
              </div>
            </div>
            
            <div>
              <h3 className="font-semibold mb-4">Related Information</h3>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-500">Project:</span>
                  <span>{ticket.project.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Contractor:</span>
                  <span>{ticket.contractor.name}</span>
                </div>
                {ticket.material && (
                  <div className="flex justify-between">
                    <span className="text-gray-500">Material:</span>
                    <span>{ticket.material.name}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span className="text-gray-500">Invoice:</span>
                  <span>
                    {ticket.invoice ? (
                      <a 
                        href={`/invoices/${ticket.invoice.id}`}
                        className="text-blue-600 hover:underline"
                      >
                        {ticket.invoice.invoiceNumber}
                      </a>
                    ) : (
                      'Not Invoiced'
                    )}
                  </span>
                </div>
              </div>
            </div>
          </div>
          
          {ticket.notes && (
            <div className="mt-6">
              <h3 className="font-semibold mb-2">Notes</h3>
              <p className="bg-gray-50 p-3 rounded">{ticket.notes}</p>
            </div>
          )}
          
          <div className="mt-8 flex gap-4">
            {ticket.status === 'LOGGED' && (
              <>
                <Button 
                  onClick={() => router.push(`/invoices/create?tickets=${ticket.id}`)}
                >
                  Create Invoice
                </Button>
                <Button 
                  variant="outline" 
                  onClick={() => handleStatusUpdate('DISPUTED')}
                >
                  Mark as Disputed
                </Button>
                <Button 
                  variant="destructive" 
                  onClick={() => handleStatusUpdate('VOID')}
                >
                  Void Ticket
                </Button>
              </>
            )}
            {ticket.status === 'DISPUTED' && (
              <Button 
                variant="outline" 
                onClick={() => handleStatusUpdate('LOGGED')}
              >
                Resolve Dispute
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
