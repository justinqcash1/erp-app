"use client";

import React from 'react';
import { useRouter } from 'next/navigation';
import { useSession } from 'next-auth/react';
import { ScopeChangeCalculatorForm } from '@/components/scope-change-calculator-form';
import { toast } from '@/components/ui/toast';

export default function ScopeChangeCalculatorPage() {
  const router = useRouter();
  const { data: session, status } = useSession();
  const [scopeItems, setScopeItems] = React.useState([]);
  const [loading, setLoading] = React.useState(true);

  // Fetch scope items on component mount
  React.useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        
        // Fetch scope items with their cost relations
        const response = await fetch('/api/scope-items?includeCostRelations=true');
        const data = await response.json();
        
        setScopeItems(data);
      } catch (error) {
        console.error('Error fetching scope items:', error);
        toast({
          title: 'Error',
          description: 'Failed to load scope items',
          variant: 'destructive',
        });
      } finally {
        setLoading(false);
      }
    };
    
    if (status === 'authenticated') {
      fetchData();
    }
  }, [status]);

  // Handle scope item change (for future use if needed)
  const handleScopeItemChange = async (scopeItemId) => {
    // This function can be used to fetch additional data when a scope item is selected
    // For now, it's a placeholder as we're already loading all the necessary data
  };

  // Handle form submission
  const handleSubmit = async (data) => {
    try {
      const response = await fetch('/api/scope-items', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          id: data.scopeItemId,
          quantity: data.newQuantity,
          unitRevenue: data.unitRevenue,
          updateCosts: data.updateCostPhases,
          changeDescription: data.description
        }),
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to apply scope change');
      }
      
      const result = await response.json();
      
      toast({
        title: 'Success',
        description: 'Scope change applied successfully',
        variant: 'success',
      });
      
      // Redirect to the scope items list or refresh the current page
      router.push('/scope-items');
    } catch (error) {
      console.error('Error applying scope change:', error);
      toast({
        title: 'Error',
        description: error.message || 'Failed to apply scope change',
        variant: 'destructive',
      });
      throw error; // Re-throw to be caught by the form component
    }
  };

  // Show loading state
  if (status === 'loading' || loading) {
    return <div>Loading...</div>;
  }

  // Redirect if not authenticated
  if (status === 'unauthenticated') {
    router.push('/auth/signin');
    return null;
  }

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-2xl font-bold mb-6">Scope Change Calculator</h1>
      
      {scopeItems.length === 0 ? (
        <div className="bg-yellow-50 p-4 rounded border border-yellow-200">
          <h3 className="font-semibold text-yellow-800 mb-2">No Scope Items Available</h3>
          <p className="text-yellow-700">
            There are no scope items available. Please create scope items with cost relations first.
          </p>
        </div>
      ) : (
        <ScopeChangeCalculatorForm
          scopeItems={scopeItems}
          onSubmit={handleSubmit}
          onScopeItemChange={handleScopeItemChange}
        />
      )}
    </div>
  );
}
