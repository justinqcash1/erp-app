"use client";

import React from 'react';
import { useRouter } from 'next/navigation';
import { useSession } from 'next-auth/react';
import { InvoiceList } from '@/components/invoice-list';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/toast';

export default function InvoicesPage() {
  const router = useRouter();
  const { data: session, status } = useSession();
  const [invoices, setInvoices] = React.useState([]);
  const [projects, setProjects] = React.useState([]);
  const [loading, setLoading] = React.useState(true);
  const [filters, setFilters] = React.useState({
    projectId: '',
    status: '',
    search: '',
    startDate: '',
    endDate: '',
  });

  // Fetch invoices and projects on component mount and when filters change
  React.useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        
        // Build query string from filters
        const queryParams = new URLSearchParams();
        if (filters.projectId) queryParams.append('projectId', filters.projectId);
        if (filters.status) queryParams.append('status', filters.status);
        if (filters.search) queryParams.append('search', filters.search);
        if (filters.startDate) queryParams.append('startDate', filters.startDate);
        if (filters.endDate) queryParams.append('endDate', filters.endDate);
        
        // Fetch invoices
        const invoicesResponse = await fetch(`/api/invoices?${queryParams.toString()}`);
        const invoicesData = await invoicesResponse.json();
        
        // Fetch projects for filter dropdown
        const projectsResponse = await fetch('/api/projects');
        const projectsData = await projectsResponse.json();
        
        setInvoices(invoicesData);
        setProjects(projectsData);
      } catch (error) {
        console.error('Error fetching data:', error);
        toast({
          title: 'Error',
          description: 'Failed to load invoices',
          variant: 'destructive',
        });
      } finally {
        setLoading(false);
      }
    };
    
    if (status === 'authenticated') {
      fetchData();
    }
  }, [status, filters]);

  // Handle filter changes
  const handleFilterChange = (newFilters) => {
    setFilters((prev) => ({ ...prev, ...newFilters }));
  };

  // Handle invoice selection for viewing details
  const handleInvoiceSelect = (invoice) => {
    router.push(`/invoices/${invoice.id}`);
  };

  // Show loading state
  if (status === 'loading' || loading) {
    return <div>Loading...</div>;
  }

  // Redirect if not authenticated
  if (status === 'unauthenticated') {
    router.push('/auth/signin');
    return null;
  }

  return (
    <div className="container mx-auto py-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Invoices</h1>
        <Button onClick={() => router.push('/invoices/create')}>
          Create New Invoice
        </Button>
      </div>
      
      <InvoiceList
        invoices={invoices}
        projects={projects}
        onFilterChange={handleFilterChange}
        onInvoiceSelect={handleInvoiceSelect}
      />
      
      <div className="mt-8">
        <h2 className="text-xl font-semibold mb-4">Invoice Verification Summary</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white p-4 rounded shadow">
            <h3 className="font-medium">Total Invoices</h3>
            <p className="text-2xl">{invoices.length}</p>
          </div>
          <div className="bg-white p-4 rounded shadow">
            <h3 className="font-medium">Pending Verification</h3>
            <p className="text-2xl">{invoices.filter(i => i.status === 'PENDING').length}</p>
          </div>
          <div className="bg-white p-4 rounded shadow">
            <h3 className="font-medium">Total Amount</h3>
            <p className="text-2xl">
              ${invoices.reduce((sum, invoice) => sum + invoice.totalAmount, 0).toFixed(2)}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
