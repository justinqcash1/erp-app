"use client";

import React from 'react';
import { useParams, useRouter } from 'next/navigation';
import { useSession } from 'next-auth/react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { toast } from '@/components/ui/toast';

export default function InvoiceDetailPage() {
  const params = useParams();
  const router = useRouter();
  const { data: session, status } = useSession();
  const [invoice, setInvoice] = React.useState(null);
  const [loading, setLoading] = React.useState(true);
  const invoiceId = params.id;

  // Fetch invoice details on component mount
  React.useEffect(() => {
    const fetchInvoice = async () => {
      try {
        setLoading(true);
        
        const response = await fetch(`/api/invoices/${invoiceId}`);
        
        if (!response.ok) {
          throw new Error('Failed to fetch invoice details');
        }
        
        const data = await response.json();
        setInvoice(data);
      } catch (error) {
        console.error('Error fetching invoice details:', error);
        toast({
          title: 'Error',
          description: error.message || 'Failed to load invoice details',
          variant: 'destructive',
        });
      } finally {
        setLoading(false);
      }
    };
    
    if (status === 'authenticated' && invoiceId) {
      fetchInvoice();
    }
  }, [status, invoiceId]);

  // Handle invoice status update
  const handleStatusUpdate = async (newStatus) => {
    try {
      const response = await fetch(`/api/invoices/${invoiceId}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ status: newStatus }),
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to update invoice status');
      }
      
      const updatedInvoice = await response.json();
      setInvoice(updatedInvoice);
      
      toast({
        title: 'Success',
        description: 'Invoice status updated successfully',
        variant: 'success',
      });
    } catch (error) {
      console.error('Error updating invoice status:', error);
      toast({
        title: 'Error',
        description: error.message || 'Failed to update invoice status',
        variant: 'destructive',
      });
    }
  };

  // Format date for display
  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString();
  };

  // Get status badge color
  const getStatusBadge = (status) => {
    switch (status) {
      case 'PENDING':
        return <Badge variant="outline">Pending</Badge>;
      case 'VERIFIED':
        return <Badge variant="success">Verified</Badge>;
      case 'PAID':
        return <Badge variant="primary">Paid</Badge>;
      case 'DISPUTED':
        return <Badge variant="destructive">Disputed</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  // Show loading state
  if (status === 'loading' || loading) {
    return <div>Loading...</div>;
  }

  // Redirect if not authenticated
  if (status === 'unauthenticated') {
    router.push('/auth/signin');
    return null;
  }

  // Show error if invoice not found
  if (!invoice) {
    return (
      <div className="container mx-auto py-8">
        <h1 className="text-2xl font-bold mb-6">Invoice Not Found</h1>
        <p>The requested invoice could not be found.</p>
        <Button className="mt-4" onClick={() => router.push('/invoices')}>
          Back to Invoices
        </Button>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Invoice Details</h1>
        <Button onClick={() => router.push('/invoices')}>
          Back to Invoices
        </Button>
      </div>
      
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle>Invoice #{invoice.invoiceNumber}</CardTitle>
            {getStatusBadge(invoice.status)}
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="font-semibold mb-4">Invoice Information</h3>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-500">Invoice Date:</span>
                  <span>{formatDate(invoice.invoiceDate)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Due Date:</span>
                  <span>{formatDate(invoice.dueDate)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Total Amount:</span>
                  <span>${invoice.totalAmount.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Status:</span>
                  <span>{getStatusBadge(invoice.status)}</span>
                </div>
              </div>
            </div>
            
            <div>
              <h3 className="font-semibold mb-4">Related Information</h3>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-500">Project:</span>
                  <span>{invoice.project.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Cost Phase:</span>
                  <span>{invoice.costPhase.code} - {invoice.costPhase.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Number of Tickets:</span>
                  <span>{invoice.tickets.length}</span>
                </div>
              </div>
            </div>
          </div>
          
          {invoice.notes && (
            <div className="mt-6">
              <h3 className="font-semibold mb-2">Notes</h3>
              <p className="bg-gray-50 p-3 rounded">{invoice.notes}</p>
            </div>
          )}
          
          <div className="mt-6">
            <h3 className="font-semibold mb-4">Associated Trucking Tickets</h3>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Ticket #</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Contractor</TableHead>
                    <TableHead>Material</TableHead>
                    <TableHead>Rate</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead className="w-12"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {invoice.tickets.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={7} className="text-center">
                        No tickets associated with this invoice
                      </TableCell>
                    </TableRow>
                  ) : (
                    invoice.tickets.map((ticket) => (
                      <TableRow key={ticket.id}>
                        <TableCell>{ticket.ticketNumber}</TableCell>
                        <TableCell>{formatDate(ticket.ticketDate)}</TableCell>
                        <TableCell>{ticket.contractor.name}</TableCell>
                        <TableCell>{ticket.material?.name || '-'}</TableCell>
                        <TableCell>${ticket.rate.toFixed(2)}</TableCell>
                        <TableCell>${ticket.totalAmount.toFixed(2)}</TableCell>
                        <TableCell>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => router.push(`/trucking-tickets/${ticket.id}`)}
                          >
                            View
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                  <TableRow>
                    <TableCell colSpan={5} className="text-right font-medium">
                      Total:
                    </TableCell>
                    <TableCell className="font-medium">
                      ${invoice.tickets.reduce((sum, ticket) => sum + ticket.totalAmount, 0).toFixed(2)}
                    </TableCell>
                    <TableCell></TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </div>
          </div>
          
          <div className="mt-8 flex gap-4">
            {invoice.status === 'PENDING' && (
              <>
                <Button 
                  variant="success" 
                  onClick={() => handleStatusUpdate('VERIFIED')}
                >
                  Verify Invoice
                </Button>
                <Button 
                  variant="destructive" 
                  onClick={() => handleStatusUpdate('DISPUTED')}
                >
                  Mark as Disputed
                </Button>
              </>
            )}
            {invoice.status === 'VERIFIED' && (
              <Button 
                variant="primary" 
                onClick={() => handleStatusUpdate('PAID')}
              >
                Mark as Paid
              </Button>
            )}
            {invoice.status === 'DISPUTED' && (
              <Button 
                variant="outline" 
                onClick={() => handleStatusUpdate('PENDING')}
              >
                Resolve Dispute
              </Button>
            )}
          </div>
          
          {/* Rate Verification Section */}
          <div className="mt-8">
            <h3 className="font-semibold mb-4">Rate Verification</h3>
            <Card>
              <CardContent className="p-4">
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span>Invoice Total:</span>
                    <span className="font-medium">${invoice.totalAmount.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Sum of Ticket Amounts:</span>
                    <span className="font-medium">
                      ${invoice.tickets.reduce((sum, ticket) => sum + ticket.totalAmount, 0).toFixed(2)}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Difference:</span>
                    <span className={`font-medium ${
                      Math.abs(invoice.totalAmount - invoice.tickets.reduce((sum, ticket) => sum + ticket.totalAmount, 0)) > 0.01
                        ? 'text-red-500'
                        : 'text-green-500'
                    }`}>
                      ${(invoice.totalAmount - invoice.tickets.reduce((sum, ticket) => sum + ticket.totalAmount, 0)).toFixed(2)}
                    </span>
                  </div>
                  
                  {Math.abs(invoice.totalAmount - invoice.tickets.reduce((sum, ticket) => sum + ticket.totalAmount, 0)) > 0.01 ? (
                    <div className="bg-red-50 p-3 rounded border border-red-200 text-red-700">
                      <strong>Warning:</strong> The invoice total does not match the sum of ticket amounts. Please verify the invoice.
                    </div>
                  ) : (
                    <div className="bg-green-50 p-3 rounded border border-green-200 text-green-700">
                      <strong>Verified:</strong> The invoice total matches the sum of ticket amounts.
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
