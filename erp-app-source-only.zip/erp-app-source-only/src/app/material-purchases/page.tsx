"use client";

import React from 'react';
import { useRouter } from 'next/navigation';
import { useSession } from 'next-auth/react';
import { MaterialPurchaseList } from '@/components/material-purchase-list';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/toast';

export default function MaterialPurchasesPage() {
  const router = useRouter();
  const { data: session, status } = useSession();
  const [purchases, setPurchases] = React.useState([]);
  const [projects, setProjects] = React.useState([]);
  const [materials, setMaterials] = React.useState([]);
  const [loading, setLoading] = React.useState(true);
  const [filters, setFilters] = React.useState({
    projectId: '',
    materialId: '',
    search: '',
    startDate: '',
    endDate: '',
    unmatchedOnly: false,
  });

  // Fetch purchases, projects, and materials on component mount and when filters change
  React.useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        
        // Build query string from filters
        const queryParams = new URLSearchParams();
        if (filters.projectId) queryParams.append('projectId', filters.projectId);
        if (filters.materialId) queryParams.append('materialId', filters.materialId);
        if (filters.search) queryParams.append('search', filters.search);
        if (filters.startDate) queryParams.append('startDate', filters.startDate);
        if (filters.endDate) queryParams.append('endDate', filters.endDate);
        if (filters.unmatchedOnly) queryParams.append('unmatchedOnly', 'true');
        
        // Fetch purchases
        const purchasesResponse = await fetch(`/api/material-purchases?${queryParams.toString()}`);
        const purchasesData = await purchasesResponse.json();
        
        // Fetch projects for filter dropdown
        const projectsResponse = await fetch('/api/projects');
        const projectsData = await projectsResponse.json();
        
        // Fetch materials for filter dropdown
        const materialsResponse = await fetch('/api/materials');
        const materialsData = await materialsResponse.json();
        
        setPurchases(purchasesData);
        setProjects(projectsData);
        setMaterials(materialsData);
      } catch (error) {
        console.error('Error fetching data:', error);
        toast({
          title: 'Error',
          description: 'Failed to load material purchases',
          variant: 'destructive',
        });
      } finally {
        setLoading(false);
      }
    };
    
    if (status === 'authenticated') {
      fetchData();
    }
  }, [status, filters]);

  // Handle filter changes
  const handleFilterChange = (newFilters) => {
    setFilters((prev) => ({ ...prev, ...newFilters }));
  };

  // Handle purchase selection for viewing details
  const handlePurchaseSelect = (purchase) => {
    router.push(`/material-purchases/${purchase.id}`);
  };

  // Show loading state
  if (status === 'loading' || loading) {
    return <div>Loading...</div>;
  }

  // Redirect if not authenticated
  if (status === 'unauthenticated') {
    router.push('/auth/signin');
    return null;
  }

  return (
    <div className="container mx-auto py-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Material Purchases</h1>
        <Button onClick={() => router.push('/material-purchases/create')}>
          Create New Purchase
        </Button>
      </div>
      
      <MaterialPurchaseList
        purchases={purchases}
        projects={projects}
        materials={materials}
        onFilterChange={handleFilterChange}
        onPurchaseSelect={handlePurchaseSelect}
      />
      
      <div className="mt-8">
        <h2 className="text-xl font-semibold mb-4">Material-Freight Alignment Summary</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white p-4 rounded shadow">
            <h3 className="font-medium">Total Material Purchases</h3>
            <p className="text-2xl">{purchases.length}</p>
          </div>
          <div className="bg-white p-4 rounded shadow">
            <h3 className="font-medium">Unmatched Purchases</h3>
            <p className="text-2xl">{purchases.filter(p => !p.ticket).length}</p>
          </div>
          <div className="bg-white p-4 rounded shadow">
            <h3 className="font-medium">Total Cost</h3>
            <p className="text-2xl">
              ${purchases.reduce((sum, purchase) => sum + purchase.totalCost, 0).toFixed(2)}
            </p>
          </div>
        </div>
      </div>
      
      <div className="mt-8">
        <h2 className="text-xl font-semibold mb-4">Material-Freight Alignment Report</h2>
        <div className="bg-white p-6 rounded shadow">
          <p className="mb-4">
            This report helps you verify that materials purchased align with the trucking tickets used to transport them.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="font-medium mb-2">Alignment Status</h3>
              <ul className="space-y-2">
                <li className="flex justify-between">
                  <span>Matched Purchases:</span>
                  <span className="font-medium">{purchases.filter(p => p.ticket).length}</span>
                </li>
                <li className="flex justify-between">
                  <span>Unmatched Purchases:</span>
                  <span className="font-medium">{purchases.filter(p => !p.ticket).length}</span>
                </li>
                <li className="flex justify-between">
                  <span>Alignment Rate:</span>
                  <span className="font-medium">
                    {purchases.length > 0 
                      ? `${((purchases.filter(p => p.ticket).length / purchases.length) * 100).toFixed(1)}%` 
                      : '0%'}
                  </span>
                </li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-medium mb-2">Cost Analysis</h3>
              <ul className="space-y-2">
                <li className="flex justify-between">
                  <span>Total Material Cost:</span>
                  <span className="font-medium">
                    ${purchases.reduce((sum, purchase) => sum + purchase.totalCost, 0).toFixed(2)}
                  </span>
                </li>
                <li className="flex justify-between">
                  <span>Matched Material Cost:</span>
                  <span className="font-medium">
                    ${purchases
                      .filter(p => p.ticket)
                      .reduce((sum, purchase) => sum + purchase.totalCost, 0)
                      .toFixed(2)}
                  </span>
                </li>
                <li className="flex justify-between">
                  <span>Unmatched Material Cost:</span>
                  <span className="font-medium">
                    ${purchases
                      .filter(p => !p.ticket)
                      .reduce((sum, purchase) => sum + purchase.totalCost, 0)
                      .toFixed(2)}
                  </span>
                </li>
              </ul>
            </div>
          </div>
          
          <div className="mt-6">
            <Button onClick={() => router.push('/reports/material-freight-alignment')}>
              View Detailed Report
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
