"use client";

import React from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { useSession } from 'next-auth/react';
import { MaterialPurchaseForm } from '@/components/material-purchase-form';
import { toast } from '@/components/ui/toast';

export default function CreateMaterialPurchasePage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { data: session, status } = useSession();
  const [projects, setProjects] = React.useState([]);
  const [materials, setMaterials] = React.useState([]);
  const [availableTickets, setAvailableTickets] = React.useState([]);
  const [loading, setLoading] = React.useState(true);
  
  // Get ticket ID from URL if provided for direct association
  const ticketId = searchParams.get('ticketId');

  // Fetch projects and materials on component mount
  React.useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        
        // Fetch projects
        const projectsResponse = await fetch('/api/projects');
        const projectsData = await projectsResponse.json();
        
        // Fetch materials
        const materialsResponse = await fetch('/api/materials');
        const materialsData = await materialsResponse.json();
        
        setProjects(projectsData);
        setMaterials(materialsData);
        
        // If ticket ID is provided, fetch the ticket details
        if (ticketId) {
          const ticketResponse = await fetch(`/api/trucking-tickets/${ticketId}`);
          const ticketData = await ticketResponse.json();
          
          // Pre-select the project from the ticket
          if (ticketData.projectId) {
            await handleProjectChange(ticketData.projectId);
          }
        }
      } catch (error) {
        console.error('Error fetching data:', error);
        toast({
          title: 'Error',
          description: 'Failed to load required data',
          variant: 'destructive',
        });
      } finally {
        setLoading(false);
      }
    };
    
    if (status === 'authenticated') {
      fetchData();
    }
  }, [status, ticketId]);

  // Fetch available tickets when project changes
  const handleProjectChange = async (projectId) => {
    try {
      // Fetch material trucking tickets for the selected project
      const response = await fetch(`/api/trucking-tickets?projectId=${projectId}&ticketType=MATERIAL`);
      const data = await response.json();
      
      // Filter to only include tickets that don't already have material purchases
      const filteredTickets = data.filter(ticket => !ticket.materialPurchase);
      
      setAvailableTickets(filteredTickets);
    } catch (error) {
      console.error('Error fetching available tickets:', error);
      toast({
        title: 'Error',
        description: 'Failed to load available tickets',
        variant: 'destructive',
      });
    }
  };

  // Handle form submission
  const handleSubmit = async (data) => {
    try {
      const response = await fetch('/api/material-purchases', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to create material purchase');
      }
      
      const purchase = await response.json();
      
      toast({
        title: 'Success',
        description: 'Material purchase created successfully',
        variant: 'success',
      });
      
      // Redirect to the material purchases list page
      router.push('/material-purchases');
    } catch (error) {
      console.error('Error creating material purchase:', error);
      toast({
        title: 'Error',
        description: error.message || 'Failed to create material purchase',
        variant: 'destructive',
      });
      throw error; // Re-throw to be caught by the form component
    }
  };

  // Show loading state
  if (status === 'loading' || loading) {
    return <div>Loading...</div>;
  }

  // Redirect if not authenticated
  if (status === 'unauthenticated') {
    router.push('/auth/signin');
    return null;
  }

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-2xl font-bold mb-6">Create Material Purchase</h1>
      
      <MaterialPurchaseForm
        projects={projects}
        materials={materials}
        availableTickets={availableTickets}
        onSubmit={handleSubmit}
        onProjectChange={handleProjectChange}
      />
    </div>
  );
}
