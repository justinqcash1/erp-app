"use client";

import React from 'react';
import { useParams, useRouter } from 'next/navigation';
import { useSession } from 'next-auth/react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { toast } from '@/components/ui/toast';

export default function LinkTicketPage() {
  const params = useParams();
  const router = useRouter();
  const { data: session, status } = useSession();
  const [purchase, setPurchase] = React.useState(null);
  const [availableTickets, setAvailableTickets] = React.useState([]);
  const [loading, setLoading] = React.useState(true);
  const purchaseId = params.id;

  // Fetch purchase details and available tickets on component mount
  React.useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        
        // Fetch purchase details
        const purchaseResponse = await fetch(`/api/material-purchases/${purchaseId}`);
        
        if (!purchaseResponse.ok) {
          throw new Error('Failed to fetch purchase details');
        }
        
        const purchaseData = await purchaseResponse.json();
        setPurchase(purchaseData);
        
        // Fetch available material trucking tickets for the same project
        const ticketsResponse = await fetch(`/api/trucking-tickets?projectId=${purchaseData.project.id}&ticketType=MATERIAL`);
        const ticketsData = await ticketsResponse.json();
        
        // Filter to only include tickets that don't already have material purchases
        const filteredTickets = ticketsData.filter(ticket => !ticket.materialPurchase);
        
        setAvailableTickets(filteredTickets);
      } catch (error) {
        console.error('Error fetching data:', error);
        toast({
          title: 'Error',
          description: error.message || 'Failed to load required data',
          variant: 'destructive',
        });
      } finally {
        setLoading(false);
      }
    };
    
    if (status === 'authenticated' && purchaseId) {
      fetchData();
    }
  }, [status, purchaseId]);

  // Handle linking purchase to ticket
  const handleLinkTicket = async (ticketId) => {
    try {
      const response = await fetch(`/api/material-purchases/${purchaseId}/link-ticket`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ ticketId }),
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to link ticket');
      }
      
      toast({
        title: 'Success',
        description: 'Material purchase linked to trucking ticket successfully',
        variant: 'success',
      });
      
      // Redirect back to the purchase detail page
      router.push(`/material-purchases/${purchaseId}`);
    } catch (error) {
      console.error('Error linking ticket:', error);
      toast({
        title: 'Error',
        description: error.message || 'Failed to link ticket',
        variant: 'destructive',
      });
    }
  };

  // Format date for display
  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString();
  };

  // Show loading state
  if (status === 'loading' || loading) {
    return <div>Loading...</div>;
  }

  // Redirect if not authenticated
  if (status === 'unauthenticated') {
    router.push('/auth/signin');
    return null;
  }

  // Show error if purchase not found
  if (!purchase) {
    return (
      <div className="container mx-auto py-8">
        <h1 className="text-2xl font-bold mb-6">Purchase Not Found</h1>
        <p>The requested material purchase could not be found.</p>
        <Button className="mt-4" onClick={() => router.push('/material-purchases')}>
          Back to Purchases
        </Button>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Link to Trucking Ticket</h1>
        <Button onClick={() => router.push(`/material-purchases/${purchaseId}`)}>
          Back to Purchase
        </Button>
      </div>
      
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Material Purchase Details</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <p><span className="font-medium">Material:</span> {purchase.material.name}</p>
              <p><span className="font-medium">Quantity:</span> {purchase.quantity} {purchase.material.unitOfMeasure}</p>
              <p><span className="font-medium">Purchase Date:</span> {formatDate(purchase.purchaseDate)}</p>
            </div>
            <div>
              <p><span className="font-medium">Project:</span> {purchase.project.name}</p>
              <p><span className="font-medium">Unit Cost:</span> ${purchase.unitCost.toFixed(2)}</p>
              <p><span className="font-medium">Total Cost:</span> ${purchase.totalCost.toFixed(2)}</p>
            </div>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle>Available Trucking Tickets</CardTitle>
        </CardHeader>
        <CardContent>
          {availableTickets.length === 0 ? (
            <div className="bg-yellow-50 p-4 rounded border border-yellow-200">
              <h3 className="font-semibold text-yellow-800 mb-2">No Available Tickets</h3>
              <p className="text-yellow-700">
                There are no available material trucking tickets for this project. Please create a new trucking ticket first.
              </p>
              <Button 
                className="mt-4" 
                onClick={() => router.push('/trucking-tickets/create')}
              >
                Create New Trucking Ticket
              </Button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Ticket #</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Contractor</TableHead>
                    <TableHead>Material</TableHead>
                    <TableHead>Quantity</TableHead>
                    <TableHead>Total</TableHead>
                    <TableHead className="w-12"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {availableTickets.map((ticket) => (
                    <TableRow key={ticket.id}>
                      <TableCell>{ticket.ticketNumber}</TableCell>
                      <TableCell>{formatDate(ticket.ticketDate)}</TableCell>
                      <TableCell>{ticket.contractor.name}</TableCell>
                      <TableCell>{ticket.material?.name || '-'}</TableCell>
                      <TableCell>{ticket.quantity} {ticket.material?.unitOfMeasure || ''}</TableCell>
                      <TableCell>${ticket.totalAmount.toFixed(2)}</TableCell>
                      <TableCell>
                        <Button
                          variant="primary"
                          size="sm"
                          onClick={() => handleLinkTicket(ticket.id)}
                        >
                          Link
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
