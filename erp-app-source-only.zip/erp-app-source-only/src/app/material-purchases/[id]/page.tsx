"use client";

import React from 'react';
import { useParams, useRouter } from 'next/navigation';
import { useSession } from 'next-auth/react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { toast } from '@/components/ui/toast';

export default function MaterialPurchaseDetailPage() {
  const params = useParams();
  const router = useRouter();
  const { data: session, status } = useSession();
  const [purchase, setPurchase] = React.useState(null);
  const [loading, setLoading] = React.useState(true);
  const purchaseId = params.id;

  // Fetch purchase details on component mount
  React.useEffect(() => {
    const fetchPurchase = async () => {
      try {
        setLoading(true);
        
        const response = await fetch(`/api/material-purchases/${purchaseId}`);
        
        if (!response.ok) {
          throw new Error('Failed to fetch purchase details');
        }
        
        const data = await response.json();
        setPurchase(data);
      } catch (error) {
        console.error('Error fetching purchase details:', error);
        toast({
          title: 'Error',
          description: error.message || 'Failed to load purchase details',
          variant: 'destructive',
        });
      } finally {
        setLoading(false);
      }
    };
    
    if (status === 'authenticated' && purchaseId) {
      fetchPurchase();
    }
  }, [status, purchaseId]);

  // Handle linking to a trucking ticket
  const handleLinkToTicket = async () => {
    try {
      // Navigate to ticket selection page with purchase ID
      router.push(`/material-purchases/${purchaseId}/link-ticket`);
    } catch (error) {
      console.error('Error navigating to link ticket page:', error);
      toast({
        title: 'Error',
        description: 'Failed to navigate to link ticket page',
        variant: 'destructive',
      });
    }
  };

  // Format date for display
  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString();
  };

  // Get alignment status badge
  const getAlignmentStatus = (purchase) => {
    if (!purchase.ticket) {
      return <Badge variant="destructive">No Ticket</Badge>;
    }
    return <Badge variant="success">Matched</Badge>;
  };

  // Show loading state
  if (status === 'loading' || loading) {
    return <div>Loading...</div>;
  }

  // Redirect if not authenticated
  if (status === 'unauthenticated') {
    router.push('/auth/signin');
    return null;
  }

  // Show error if purchase not found
  if (!purchase) {
    return (
      <div className="container mx-auto py-8">
        <h1 className="text-2xl font-bold mb-6">Purchase Not Found</h1>
        <p>The requested material purchase could not be found.</p>
        <Button className="mt-4" onClick={() => router.push('/material-purchases')}>
          Back to Purchases
        </Button>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Material Purchase Details</h1>
        <Button onClick={() => router.push('/material-purchases')}>
          Back to Purchases
        </Button>
      </div>
      
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle>Material Purchase</CardTitle>
            {getAlignmentStatus(purchase)}
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="font-semibold mb-4">Purchase Information</h3>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-500">Purchase Date:</span>
                  <span>{formatDate(purchase.purchaseDate)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Material:</span>
                  <span>{purchase.material.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Quantity:</span>
                  <span>{purchase.quantity} {purchase.material.unitOfMeasure}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Unit Cost:</span>
                  <span>${purchase.unitCost.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Total Cost:</span>
                  <span>${purchase.totalCost.toFixed(2)}</span>
                </div>
                {purchase.purchaseOrder && (
                  <div className="flex justify-between">
                    <span className="text-gray-500">Purchase Order:</span>
                    <span>{purchase.purchaseOrder}</span>
                  </div>
                )}
              </div>
            </div>
            
            <div>
              <h3 className="font-semibold mb-4">Related Information</h3>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-500">Project:</span>
                  <span>{purchase.project.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Trucking Ticket:</span>
                  <span>
                    {purchase.ticket ? (
                      <a 
                        href={`/trucking-tickets/${purchase.ticket.id}`}
                        className="text-blue-600 hover:underline"
                      >
                        {purchase.ticket.ticketNumber}
                      </a>
                    ) : (
                      'Not Linked'
                    )}
                  </span>
                </div>
                {purchase.ticket && (
                  <div className="flex justify-between">
                    <span className="text-gray-500">Contractor:</span>
                    <span>{purchase.ticket.contractor.name}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span className="text-gray-500">Alignment Status:</span>
                  <span>{getAlignmentStatus(purchase)}</span>
                </div>
              </div>
            </div>
          </div>
          
          {purchase.notes && (
            <div className="mt-6">
              <h3 className="font-semibold mb-2">Notes</h3>
              <p className="bg-gray-50 p-3 rounded">{purchase.notes}</p>
            </div>
          )}
          
          {!purchase.ticket && (
            <div className="mt-8">
              <div className="bg-yellow-50 p-4 rounded border border-yellow-200 mb-4">
                <h3 className="font-semibold text-yellow-800 mb-2">Material-Freight Alignment Issue</h3>
                <p className="text-yellow-700">
                  This material purchase is not linked to any trucking ticket. To maintain proper material-freight alignment, 
                  you should link this purchase to the trucking ticket that was used to transport this material.
                </p>
              </div>
              
              <Button onClick={handleLinkToTicket}>
                Link to Trucking Ticket
              </Button>
            </div>
          )}
          
          {purchase.ticket && (
            <div className="mt-8">
              <h3 className="font-semibold mb-4">Material-Freight Alignment</h3>
              <div className="bg-green-50 p-4 rounded border border-green-200">
                <h4 className="font-medium text-green-800 mb-2">Alignment Verified</h4>
                <p className="text-green-700 mb-4">
                  This material purchase is properly linked to trucking ticket #{purchase.ticket.ticketNumber}.
                </p>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <h5 className="font-medium mb-2">Material Details</h5>
                    <ul className="space-y-1">
                      <li><span className="text-gray-600">Material:</span> {purchase.material.name}</li>
                      <li><span className="text-gray-600">Quantity:</span> {purchase.quantity} {purchase.material.unitOfMeasure}</li>
                      <li><span className="text-gray-600">Total Cost:</span> ${purchase.totalCost.toFixed(2)}</li>
                    </ul>
                  </div>
                  
                  <div>
                    <h5 className="font-medium mb-2">Trucking Details</h5>
                    <ul className="space-y-1">
                      <li><span className="text-gray-600">Ticket:</span> #{purchase.ticket.ticketNumber}</li>
                      <li><span className="text-gray-600">Contractor:</span> {purchase.ticket.contractor.name}</li>
                      <li><span className="text-gray-600">Date:</span> {formatDate(purchase.ticket.ticketDate)}</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
