"use client";

import React from 'react';
import { useParams, useRouter } from 'next/navigation';
import { useSession } from 'next-auth/react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { toast } from '@/components/ui/toast';

export default function ScopeChangeDetailPage() {
  const params = useParams();
  const router = useRouter();
  const { data: session, status } = useSession();
  const [scopeChange, setScopeChange] = React.useState(null);
  const [loading, setLoading] = React.useState(true);
  const changeId = params.id;

  // Fetch scope change details on component mount
  React.useEffect(() => {
    const fetchScopeChange = async () => {
      try {
        setLoading(true);
        
        const response = await fetch(`/api/scope-changes/${changeId}`);
        
        if (!response.ok) {
          throw new Error('Failed to fetch scope change details');
        }
        
        const data = await response.json();
        setScopeChange(data);
      } catch (error) {
        console.error('Error fetching scope change details:', error);
        toast({
          title: 'Error',
          description: error.message || 'Failed to load scope change details',
          variant: 'destructive',
        });
      } finally {
        setLoading(false);
      }
    };
    
    if (status === 'authenticated' && changeId) {
      fetchScopeChange();
    }
  }, [status, changeId]);

  // Format date for display
  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString();
  };

  // Show loading state
  if (status === 'loading' || loading) {
    return <div>Loading...</div>;
  }

  // Redirect if not authenticated
  if (status === 'unauthenticated') {
    router.push('/auth/signin');
    return null;
  }

  // Show error if scope change not found
  if (!scopeChange) {
    return (
      <div className="container mx-auto py-8">
        <h1 className="text-2xl font-bold mb-6">Scope Change Not Found</h1>
        <p>The requested scope change could not be found.</p>
        <Button className="mt-4" onClick={() => router.push('/scope-changes')}>
          Back to Scope Changes
        </Button>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Scope Change Details</h1>
        <Button onClick={() => router.push('/scope-changes')}>
          Back to Scope Changes
        </Button>
      </div>
      
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Scope Change Summary</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="font-semibold mb-4">Change Information</h3>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-500">Date:</span>
                  <span>{formatDate(scopeChange.createdAt)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Scope Item:</span>
                  <span>{scopeChange.scopeItem.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Original Quantity:</span>
                  <span>{scopeChange.originalQuantity} {scopeChange.scopeItem.unitOfMeasure}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">New Quantity:</span>
                  <span>{scopeChange.newQuantity} {scopeChange.scopeItem.unitOfMeasure}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Unit Revenue:</span>
                  <span>${scopeChange.unitRevenue.toFixed(2)}</span>
                </div>
              </div>
            </div>
            
            <div>
              <h3 className="font-semibold mb-4">Impact Summary</h3>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-500">Original Total Revenue:</span>
                  <span>${scopeChange.originalTotalRevenue.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">New Total Revenue:</span>
                  <span>${scopeChange.newTotalRevenue.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Revenue Impact:</span>
                  <span className={scopeChange.revenueImpact >= 0 ? 'text-green-600' : 'text-red-600'}>
                    ${scopeChange.revenueImpact.toFixed(2)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Cost Impact:</span>
                  <span className={scopeChange.costImpact >= 0 ? 'text-green-600' : 'text-red-600'}>
                    ${scopeChange.costImpact.toFixed(2)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Changed By:</span>
                  <span>{scopeChange.user.name}</span>
                </div>
              </div>
            </div>
          </div>
          
          {scopeChange.description && (
            <div className="mt-6">
              <h3 className="font-semibold mb-2">Change Description</h3>
              <p className="bg-gray-50 p-3 rounded">{scopeChange.description}</p>
            </div>
          )}
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle>Cost Phase Adjustments</CardTitle>
        </CardHeader>
        <CardContent>
          {!scopeChange.costAdjustments || scopeChange.costAdjustments.length === 0 ? (
            <div className="text-center py-4">
              <p>No cost phases were adjusted with this scope change.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Cost Phase</TableHead>
                    <TableHead>Original Quantity</TableHead>
                    <TableHead>New Quantity</TableHead>
                    <TableHead>Unit Cost</TableHead>
                    <TableHead>Original Total</TableHead>
                    <TableHead>New Total</TableHead>
                    <TableHead>Impact</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {scopeChange.costAdjustments.map((adjustment) => (
                    <TableRow key={adjustment.id}>
                      <TableCell>{adjustment.costPhase.code} - {adjustment.costPhase.name}</TableCell>
                      <TableCell>{adjustment.originalQuantity.toFixed(2)}</TableCell>
                      <TableCell>{adjustment.newQuantity.toFixed(2)}</TableCell>
                      <TableCell>${adjustment.unitCost.toFixed(2)}</TableCell>
                      <TableCell>${adjustment.originalTotalCost.toFixed(2)}</TableCell>
                      <TableCell>${adjustment.newTotalCost.toFixed(2)}</TableCell>
                      <TableCell className={adjustment.costImpact >= 0 ? 'text-green-600' : 'text-red-600'}>
                        ${adjustment.costImpact.toFixed(2)}
                      </TableCell>
                    </TableRow>
                  ))}
                  <TableRow>
                    <TableCell colSpan={6} className="text-right font-medium">Total Cost Impact:</TableCell>
                    <TableCell className={scopeChange.costImpact >= 0 ? 'text-green-600 font-medium' : 'text-red-600 font-medium'}>
                      ${scopeChange.costImpact.toFixed(2)}
                    </TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
