"use client";

import React from 'react';
import { useRouter } from 'next/navigation';
import { useSession } from 'next-auth/react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { toast } from '@/components/ui/toast';

export default function ScopeChangeHistoryPage() {
  const router = useRouter();
  const { data: session, status } = useSession();
  const [scopeChanges, setScopeChanges] = React.useState([]);
  const [loading, setLoading] = React.useState(true);

  // Fetch scope change history on component mount
  React.useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        
        // Fetch scope change history
        const response = await fetch('/api/scope-changes');
        const data = await response.json();
        
        setScopeChanges(data);
      } catch (error) {
        console.error('Error fetching scope changes:', error);
        toast({
          title: 'Error',
          description: 'Failed to load scope change history',
          variant: 'destructive',
        });
      } finally {
        setLoading(false);
      }
    };
    
    if (status === 'authenticated') {
      fetchData();
    }
  }, [status]);

  // Format date for display
  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString();
  };

  // Show loading state
  if (status === 'loading' || loading) {
    return <div>Loading...</div>;
  }

  // Redirect if not authenticated
  if (status === 'unauthenticated') {
    router.push('/auth/signin');
    return null;
  }

  return (
    <div className="container mx-auto py-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Scope Change History</h1>
        <Button onClick={() => router.push('/scope-change-calculator')}>
          New Scope Change
        </Button>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Recent Scope Changes</CardTitle>
        </CardHeader>
        <CardContent>
          {scopeChanges.length === 0 ? (
            <div className="text-center py-4">
              <p>No scope changes have been recorded yet.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Date</TableHead>
                    <TableHead>Scope Item</TableHead>
                    <TableHead>Original Quantity</TableHead>
                    <TableHead>New Quantity</TableHead>
                    <TableHead>Revenue Impact</TableHead>
                    <TableHead>Cost Impact</TableHead>
                    <TableHead>Changed By</TableHead>
                    <TableHead className="w-12"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {scopeChanges.map((change) => (
                    <TableRow key={change.id}>
                      <TableCell>{formatDate(change.createdAt)}</TableCell>
                      <TableCell>{change.scopeItem.name}</TableCell>
                      <TableCell>{change.originalQuantity} {change.scopeItem.unitOfMeasure}</TableCell>
                      <TableCell>{change.newQuantity} {change.scopeItem.unitOfMeasure}</TableCell>
                      <TableCell className={change.revenueImpact >= 0 ? 'text-green-600' : 'text-red-600'}>
                        ${change.revenueImpact.toFixed(2)}
                      </TableCell>
                      <TableCell className={change.costImpact >= 0 ? 'text-green-600' : 'text-red-600'}>
                        ${change.costImpact.toFixed(2)}
                      </TableCell>
                      <TableCell>{change.user.name}</TableCell>
                      <TableCell>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => router.push(`/scope-changes/${change.id}`)}
                        >
                          View
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
      
      <div className="mt-8">
        <h2 className="text-xl font-semibold mb-4">Scope Change Impact Summary</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white p-4 rounded shadow">
            <h3 className="font-medium">Total Changes</h3>
            <p className="text-2xl">{scopeChanges.length}</p>
          </div>
          <div className="bg-white p-4 rounded shadow">
            <h3 className="font-medium">Net Revenue Impact</h3>
            <p className={`text-2xl ${
              scopeChanges.reduce((sum, change) => sum + change.revenueImpact, 0) >= 0 
                ? 'text-green-600' 
                : 'text-red-600'
            }`}>
              ${scopeChanges.reduce((sum, change) => sum + change.revenueImpact, 0).toFixed(2)}
            </p>
          </div>
          <div className="bg-white p-4 rounded shadow">
            <h3 className="font-medium">Net Cost Impact</h3>
            <p className={`text-2xl ${
              scopeChanges.reduce((sum, change) => sum + change.costImpact, 0) >= 0 
                ? 'text-green-600' 
                : 'text-red-600'
            }`}>
              ${scopeChanges.reduce((sum, change) => sum + change.costImpact, 0).toFixed(2)}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
