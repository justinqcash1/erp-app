import { NextResponse } from 'next/server';
import { getAuthSession } from '@/lib/auth';
import prisma from '@/lib/prisma';

// API route to create a new scope item
export async function POST(request: Request) {
  try {
    const session = await getAuthSession();
    
    if (!session?.user) {
      return NextResponse.json(
        { error: 'You must be logged in to create a scope item' },
        { status: 401 }
      );
    }
    
    const body = await request.json();
    const {
      name,
      description,
      unitOfMeasure,
      quantity,
      unitRevenue,
      projectId,
      costRelations
    } = body;
    
    // Validate required fields
    if (!name || !unitOfMeasure || !quantity || !unitRevenue || !projectId) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      );
    }
    
    // Calculate total revenue
    const totalRevenue = quantity * unitRevenue;
    
    // Create the scope item and cost relations in a transaction
    const scopeItem = await prisma.$transaction(async (tx) => {
      // Create the scope item
      const newScopeItem = await tx.scopeItem.create({
        data: {
          name,
          description: description || null,
          unitOfMeasure,
          quantity,
          unitRevenue,
          totalRevenue,
          project: {
            connect: { id: projectId }
          }
        }
      });
      
      // Create cost relations if provided
      if (costRelations && costRelations.length > 0) {
        await Promise.all(
          costRelations.map(async (relation: { costPhaseId: string, ratio: number }) => {
            await tx.scopeItemCostRelation.create({
              data: {
                ratio: relation.ratio,
                scopeItem: {
                  connect: { id: newScopeItem.id }
                },
                costPhase: {
                  connect: { id: relation.costPhaseId }
                }
              }
            });
          })
        );
      }
      
      return newScopeItem;
    });
    
    return NextResponse.json(scopeItem, { status: 201 });
  } catch (error) {
    console.error('Error creating scope item:', error);
    return NextResponse.json(
      { error: 'Failed to create scope item' },
      { status: 500 }
    );
  }
}

// API route to update a scope item and recalculate related cost phases
export async function PUT(request: Request) {
  try {
    const session = await getAuthSession();
    
    if (!session?.user) {
      return NextResponse.json(
        { error: 'You must be logged in to update a scope item' },
        { status: 401 }
      );
    }
    
    const body = await request.json();
    const {
      id,
      name,
      description,
      unitOfMeasure,
      quantity,
      unitRevenue,
      updateCosts
    } = body;
    
    // Validate required fields
    if (!id || !name || !unitOfMeasure || !quantity || !unitRevenue) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      );
    }
    
    // Calculate total revenue
    const totalRevenue = quantity * unitRevenue;
    
    // Get the existing scope item with its cost relations
    const existingScopeItem = await prisma.scopeItem.findUnique({
      where: { id },
      include: {
        costRelations: {
          include: {
            costPhase: true
          }
        }
      }
    });
    
    if (!existingScopeItem) {
      return NextResponse.json(
        { error: 'Scope item not found' },
        { status: 404 }
      );
    }
    
    // Calculate quantity change ratio
    const quantityChangeRatio = quantity / existingScopeItem.quantity;
    
    // Update the scope item and related cost phases in a transaction
    const result = await prisma.$transaction(async (tx) => {
      // Update the scope item
      const updatedScopeItem = await tx.scopeItem.update({
        where: { id },
        data: {
          name,
          description: description || null,
          unitOfMeasure,
          quantity,
          unitRevenue,
          totalRevenue
        }
      });
      
      // Update related cost phases if requested
      if (updateCosts && existingScopeItem.costRelations.length > 0) {
        await Promise.all(
          existingScopeItem.costRelations.map(async (relation) => {
            const costPhase = relation.costPhase;
            const newQuantity = costPhase.quantity * (1 + (quantityChangeRatio - 1) * relation.ratio);
            const newTotalCost = newQuantity * costPhase.unitCost;
            
            await tx.costPhase.update({
              where: { id: costPhase.id },
              data: {
                quantity: newQuantity,
                totalCost: newTotalCost
              }
            });
          })
        );
      }
      
      return {
        scopeItem: updatedScopeItem,
        quantityChangeRatio,
        costsUpdated: updateCosts && existingScopeItem.costRelations.length > 0
      };
    });
    
    return NextResponse.json(result);
  } catch (error) {
    console.error('Error updating scope item:', error);
    return NextResponse.json(
      { error: 'Failed to update scope item' },
      { status: 500 }
    );
  }
}
