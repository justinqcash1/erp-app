import { NextResponse } from 'next/server';
import { getAuthSession } from '@/lib/auth';
import prisma from '@/lib/prisma';

// API route to create a new invoice
export async function POST(request: Request) {
  try {
    const session = await getAuthSession();
    
    if (!session?.user) {
      return NextResponse.json(
        { error: 'You must be logged in to create an invoice' },
        { status: 401 }
      );
    }
    
    const body = await request.json();
    const {
      invoiceNumber,
      invoiceDate,
      dueDate,
      totalAmount,
      projectId,
      costPhaseId,
      notes,
      ticketIds
    } = body;
    
    // Validate required fields
    if (!invoiceNumber || !invoiceDate || !dueDate || !totalAmount || !projectId || !costPhaseId) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      );
    }
    
    // Check for duplicate invoice number
    const existingInvoice = await prisma.invoice.findUnique({
      where: {
        invoiceNumber: invoiceNumber
      }
    });
    
    if (existingInvoice) {
      return NextResponse.json(
        { error: 'Invoice number already exists' },
        { status: 400 }
      );
    }
    
    // Create the invoice and connect tickets in a transaction
    const invoice = await prisma.$transaction(async (tx) => {
      // Create the invoice
      const newInvoice = await tx.invoice.create({
        data: {
          invoiceNumber,
          invoiceDate: new Date(invoiceDate),
          dueDate: new Date(dueDate),
          totalAmount,
          status: 'PENDING',
          notes: notes || null,
          project: {
            connect: { id: projectId }
          },
          costPhase: {
            connect: { id: costPhaseId }
          },
          user: {
            connect: { id: session.user.id }
          }
        }
      });
      
      // Connect tickets to the invoice if provided
      if (ticketIds && ticketIds.length > 0) {
        await Promise.all(
          ticketIds.map(async (ticketId: string) => {
            await tx.truckingTicket.update({
              where: { id: ticketId },
              data: {
                status: 'INVOICED',
                invoice: {
                  connect: { id: newInvoice.id }
                }
              }
            });
          })
        );
      }
      
      return newInvoice;
    });
    
    return NextResponse.json(invoice, { status: 201 });
  } catch (error) {
    console.error('Error creating invoice:', error);
    return NextResponse.json(
      { error: 'Failed to create invoice' },
      { status: 500 }
    );
  }
}

// API route to get all invoices with filtering options
export async function GET(request: Request) {
  try {
    const session = await getAuthSession();
    
    if (!session?.user) {
      return NextResponse.json(
        { error: 'You must be logged in to view invoices' },
        { status: 401 }
      );
    }
    
    const { searchParams } = new URL(request.url);
    const projectId = searchParams.get('projectId');
    const status = searchParams.get('status');
    const startDate = searchParams.get('startDate');
    const endDate = searchParams.get('endDate');
    
    // Build filter conditions
    const where: any = {};
    
    if (projectId) {
      where.projectId = projectId;
    }
    
    if (status) {
      where.status = status;
    }
    
    if (startDate || endDate) {
      where.invoiceDate = {};
      
      if (startDate) {
        where.invoiceDate.gte = new Date(startDate);
      }
      
      if (endDate) {
        where.invoiceDate.lte = new Date(endDate);
      }
    }
    
    // Get invoices with related data
    const invoices = await prisma.invoice.findMany({
      where,
      include: {
        project: {
          select: {
            id: true,
            name: true
          }
        },
        costPhase: {
          select: {
            id: true,
            name: true,
            code: true
          }
        },
        tickets: {
          select: {
            id: true,
            ticketNumber: true,
            totalAmount: true
          }
        }
      },
      orderBy: {
        invoiceDate: 'desc'
      }
    });
    
    return NextResponse.json(invoices);
  } catch (error) {
    console.error('Error fetching invoices:', error);
    return NextResponse.json(
      { error: 'Failed to fetch invoices' },
      { status: 500 }
    );
  }
}
