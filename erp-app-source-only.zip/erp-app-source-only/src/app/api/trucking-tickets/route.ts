import { NextResponse } from 'next/server';
import { getAuthSession } from '@/lib/auth';
import prisma from '@/lib/prisma';

// API route to create a new trucking ticket
export async function POST(request: Request) {
  try {
    const session = await getAuthSession();
    
    if (!session?.user) {
      return NextResponse.json(
        { error: 'You must be logged in to create a ticket' },
        { status: 401 }
      );
    }
    
    const body = await request.json();
    const {
      ticketNumber,
      ticketDate,
      projectId,
      materialId,
      contractorId,
      quantity,
      hours,
      rate,
      totalAmount,
      ticketType,
      notes
    } = body;
    
    // Validate required fields
    if (!ticketNumber || !ticketDate || !projectId || !contractorId || !rate || !totalAmount || !ticketType) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      );
    }
    
    // Check for duplicate ticket number
    const existingTicket = await prisma.truckingTicket.findUnique({
      where: {
        ticketNumber: ticketNumber
      }
    });
    
    if (existingTicket) {
      return NextResponse.json(
        { error: 'Ticket number already exists' },
        { status: 400 }
      );
    }
    
    // Create the trucking ticket
    const ticket = await prisma.truckingTicket.create({
      data: {
        ticketNumber,
        ticketDate: new Date(ticketDate),
        quantity: quantity || null,
        hours: hours || null,
        rate,
        totalAmount,
        ticketType,
        notes: notes || null,
        status: 'LOGGED',
        project: {
          connect: { id: projectId }
        },
        contractor: {
          connect: { id: contractorId }
        },
        user: {
          connect: { id: session.user.id }
        },
        ...(materialId && {
          material: {
            connect: { id: materialId }
          }
        })
      }
    });
    
    return NextResponse.json(ticket, { status: 201 });
  } catch (error) {
    console.error('Error creating trucking ticket:', error);
    return NextResponse.json(
      { error: 'Failed to create trucking ticket' },
      { status: 500 }
    );
  }
}

// API route to get all trucking tickets with filtering options
export async function GET(request: Request) {
  try {
    const session = await getAuthSession();
    
    if (!session?.user) {
      return NextResponse.json(
        { error: 'You must be logged in to view tickets' },
        { status: 401 }
      );
    }
    
    const { searchParams } = new URL(request.url);
    const projectId = searchParams.get('projectId');
    const status = searchParams.get('status');
    const ticketType = searchParams.get('ticketType');
    const invoiced = searchParams.get('invoiced');
    
    // Build filter conditions
    const where: any = {};
    
    if (projectId) {
      where.projectId = projectId;
    }
    
    if (status) {
      where.status = status;
    }
    
    if (ticketType) {
      where.ticketType = ticketType;
    }
    
    if (invoiced === 'true') {
      where.invoiceId = { not: null };
    } else if (invoiced === 'false') {
      where.invoiceId = null;
    }
    
    // Get tickets with related data
    const tickets = await prisma.truckingTicket.findMany({
      where,
      include: {
        project: {
          select: {
            id: true,
            name: true
          }
        },
        material: {
          select: {
            id: true,
            name: true,
            unitOfMeasure: true
          }
        },
        contractor: {
          select: {
            id: true,
            name: true
          }
        },
        invoice: {
          select: {
            id: true,
            invoiceNumber: true
          }
        }
      },
      orderBy: {
        ticketDate: 'desc'
      }
    });
    
    return NextResponse.json(tickets);
  } catch (error) {
    console.error('Error fetching trucking tickets:', error);
    return NextResponse.json(
      { error: 'Failed to fetch trucking tickets' },
      { status: 500 }
    );
  }
}
